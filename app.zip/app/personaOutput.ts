export interface PersonaOutput{ // del  backend al frontend
    id : string;
    user : string;
    password : string ;
    name : string ;
    surname : string;
    company_email : string;
    personal_email : string;
    city : string;
    imagen_url : string;
    termination_date : string;
    created_date : string;
    active : string;
   

    
}