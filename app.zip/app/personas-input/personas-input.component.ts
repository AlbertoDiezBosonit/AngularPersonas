import { Component, OnInit } from '@angular/core';
import { PersonaOutput } from '../personaOutput';

@Component({
  selector: 'app-personas-input',
  templateUrl: './personas-input.component.html',
  styleUrls: ['./personas-input.component.css']
})
export class PersonasInputComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
